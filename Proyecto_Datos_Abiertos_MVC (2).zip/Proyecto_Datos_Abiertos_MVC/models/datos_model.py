import json
import os
import pyodbc
from dotenv import load_dotenv

load_dotenv()

def obtener_conexion():
    servidor = os.getenv("DB_SERVER", "localhost")
    base_datos = os.getenv("DB_NAME", "DatosAbiertosDB")
    driver = os.getenv("DB_DRIVER", "ODBC Driver 18 for SQL Server")
    trusted = os.getenv("DB_TRUSTED", "yes").lower() == "yes"

    if trusted:
        cadena = (
            f"DRIVER={{{driver}}};SERVER={servidor};DATABASE={base_datos};"
            "Trusted_Connection=yes;TrustServerCertificate=yes;"
        )
    else:
        usuario = os.getenv("DB_USER", "")
        clave = os.getenv("DB_PASSWORD", "")
        cadena = (
            f"DRIVER={{{driver}}};SERVER={servidor};DATABASE={base_datos};"
            f"UID={usuario};PWD={clave};TrustServerCertificate=yes;"
        )
    return pyodbc.connect(cadena)

def guardar_registros(registros):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    insertados = 0
    try:
        for registro in registros:
            codigo = str(registro.get("codigo_dane") or "").strip()
            anio = str(registro.get("a_o") or "").strip()
            if not codigo:
                continue
            # La combinación código DANE + año evita repetir el mismo establecimiento/año.
            identificador = f"{codigo}-{anio or 'SIN_ANIO'}"
            cursor.execute("""
                IF NOT EXISTS (SELECT 1 FROM Establecimientos WHERE id_api = ?)
                INSERT INTO Establecimientos
                (id_api, codigo_dane, anio, departamento, municipio,
                 nombre_establecimiento, sector, caracter, calendario, json_original)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                identificador, identificador, codigo, anio or None,
                registro.get("departamento"), registro.get("municipio"),
                registro.get("nombre_establecimiento"), registro.get("sector"),
                registro.get("caracter"), registro.get("calendario"),
                json.dumps(registro, ensure_ascii=False)
            )
            if cursor.rowcount > 0:
                insertados += 1
        conexion.commit()
        return insertados
    except Exception:
        conexion.rollback()
        raise
    finally:
        cursor.close()
        conexion.close()

def consultar_registros(filtro=""):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    try:
        if filtro:
            patron = f"%{filtro}%"
            cursor.execute("""
                SELECT TOP 100 id_api, codigo_dane, anio, departamento, municipio,
                       nombre_establecimiento, sector, caracter, calendario
                FROM Establecimientos
                WHERE municipio LIKE ? OR departamento LIKE ?
                   OR nombre_establecimiento LIKE ? OR sector LIKE ?
                ORDER BY id DESC
            """, patron, patron, patron, patron)
        else:
            cursor.execute("""
                SELECT TOP 100 id_api, codigo_dane, anio, departamento, municipio,
                       nombre_establecimiento, sector, caracter, calendario
                FROM Establecimientos ORDER BY id DESC
            """)
        columnas = [columna[0] for columna in cursor.description]
        return [dict(zip(columnas, fila)) for fila in cursor.fetchall()]
    finally:
        cursor.close()
        conexion.close()

def obtener_resumen():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    try:
        cursor.execute("""
            SELECT COUNT(*) AS total,
                   COUNT(DISTINCT municipio) AS municipios,
                   COUNT(DISTINCT departamento) AS departamentos
            FROM Establecimientos
        """)
        fila = cursor.fetchone()
        return {"total": fila[0], "municipios": fila[1], "departamentos": fila[2]}
    finally:
        cursor.close()
        conexion.close()
