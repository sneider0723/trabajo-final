# Sistema Web de Consulta y Análisis de Datos Educativos de Colombia

## 1. Descripción
Aplicación académica que consulta el conjunto público **MEN_ESTABLECIMIENTOS_EDUCATIVOS_PREESCOLAR_BÁSICA_Y_MEDIA** del Ministerio de Educación Nacional, recibe información JSON mediante la API REST de datos.gov.co, guarda una selección de campos en SQL Server y permite consultarlos desde una página web Flask organizada con MVC.

**Fuente:** https://www.datos.gov.co/Educaci-n/MEN_ESTABLECIMIENTOS_EDUCATIVOS_PREESCOLAR_B-SICA_/cfw5-qzt5  
**Identificador del recurso:** `cfw5-qzt5`  
**Endpoint:** `https://www.datos.gov.co/resource/cfw5-qzt5.json?$limit=100`  
**Propósito:** consultar información de establecimientos educativos de preescolar, básica y media en Colombia.  
**Entidad:** Ministerio de Educación Nacional.  
**Cobertura:** nacional. La ficha consultada reporta 24 columnas y alrededor de 606 mil filas; el aplicativo descarga solo 100 registros por sincronización para mantener el ejercicio manejable.

## 2. Campos utilizados
- `a_o`: año del reporte.
- `departamento`: departamento.
- `municipio`: municipio.
- `codigo_dane`: código del establecimiento.
- `nombre_establecimiento`: nombre del establecimiento.
- `sector`: sector educativo.
- `caracter`: carácter del establecimiento.
- `calendario`: calendario académico.

La clave para evitar duplicados se construye con `codigo_dane + a_o`, ya que un establecimiento puede aparecer en más de un año. Se conserva además el JSON original.

## 3. Tecnologías y requisitos
- Python 3.10 o superior.
- Flask, Requests, pyodbc y python-dotenv.
- Microsoft SQL Server y SSMS.
- Microsoft ODBC Driver 18 for SQL Server.
- Navegador web y conexión a Internet.

## 4. Instalación
1. Instalar Python, SQL Server, SSMS y el controlador ODBC.
2. Abrir esta carpeta en Visual Studio Code.
3. Crear y activar el entorno virtual:

   Windows PowerShell:
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   ```
4. Instalar dependencias:
   ```bash
   pip install -r requirements.txt
   ```
5. Copiar `.env.example` y nombrar la copia `.env`.
6. Ajustar `DB_SERVER`, `DB_NAME` y el tipo de autenticación. No publicar el archivo `.env`.

## 5. Crear la base de datos
Abrir SQL Server Management Studio, conectarse al servidor y ejecutar el archivo `sql/crear_base_datos.sql`. El script crea `DatosAbiertosDB` y la tabla `Establecimientos`.

Si la instancia local no se llama `localhost`, modificar `DB_SERVER`. Ejemplos habituales: `localhost\\SQLEXPRESS` o `NOMBRE-EQUIPO\\SQLEXPRESS`.

## 6. Ejecutar
Desde la carpeta principal y con el entorno virtual activo:
```bash
python app.py
```
Abrir http://127.0.0.1:5000. Pulsar **Consultar API y guardar datos**. Después se puede filtrar por municipio, departamento, nombre del establecimiento o sector.

## 7. Arquitectura MVC
- **Modelo:** `models/datos_model.py`. Abre la conexión pyodbc, inserta registros evitando duplicados, consulta la tabla y calcula los indicadores.
- **Vista:** `templates/index.html` y `static/estilos.css`. Presenta los formularios, mensajes, indicadores y tabla.
- **Controlador:** `app.py`. Atiende las rutas `/` y `/sincronizar`, coordina API y modelo y envía datos a la vista.
- **Servicio API:** `api/api_client.py`. Realiza la petición HTTP y convierte la respuesta JSON.

Flujo: navegador → controlador Flask → cliente API / modelo SQL Server → controlador → vista HTML → navegador.

## 8. Pruebas
1. Confirmar que SQL Server esté iniciado.
2. Verificar que el `.env` tenga el servidor y la base correctos.
3. Ejecutar `python app.py`.
4. Abrir la página y sincronizar.
5. Verificar en SSMS: `SELECT TOP 20 * FROM Establecimientos ORDER BY id DESC;`
6. Buscar un municipio o departamento en el formulario.
7. Sincronizar otra vez y comprobar que la restricción UNIQUE y la clave compuesta evitan duplicados.

## 9. Errores frecuentes
- `ModuleNotFoundError`: activar `venv` e instalar `requirements.txt`.
- `Data source name not found`: instalar ODBC Driver 18 y revisar el nombre exacto en `.env`.
- `Login failed`: verificar autenticación de Windows o credenciales SQL.
- `Invalid object name`: ejecutar el script SQL en la base correcta.
- HTTP 404: comprobar el identificador `cfw5-qzt5` y el endpoint.
- HTTP 429: reducir frecuencia y cantidad de solicitudes.
- No aparecen filas: revisar el JSON y los nombres reales de los campos.

## 10. Límites
La aplicación carga hasta 100 registros por sincronización y muestra hasta 100 resultados por consulta. No implementa CRUD completo, autenticación, edición, eliminación, paginación ni despliegue público. Los nombres de campos deben validarse contra el JSON vigente antes de la demostración.

## 11. Distribución sugerida para tres integrantes
- **Sneider Castro:** selección del dataset, endpoint, API y lectura JSON.
- **Valery Arrieta Hoyos:** SQL Server, tabla, conexión pyodbc, inserción y consultas.
- **Owen de la Hoz:** Flask, rutas, HTML, CSS y presentación.
- Todos: integración, pruebas, documentación y sustentación.

## 12. Entregables
Código fuente, script SQL, `requirements.txt`, README, evidencia JSON, evidencia de datos en SQL Server, capturas de la página principal/sincronización/búsqueda y presentación de sustentación.
