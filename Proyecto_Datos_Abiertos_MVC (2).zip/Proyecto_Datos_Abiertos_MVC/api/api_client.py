import os
import requests
from dotenv import load_dotenv

load_dotenv()

class APIClient:
    """Cliente para consultar el conjunto de establecimientos educativos en datos.gov.co."""
    def __init__(self):
        recurso = os.getenv("API_RESOURCE_ID", "cfw5-qzt5")
        self.url = f"https://www.datos.gov.co/resource/{recurso}.json"

    def obtener_registros(self, limite=100):
        parametros = {
            "$limit": limite,
            "$order": "a_o DESC"
        }
        respuesta = requests.get(self.url, params=parametros, timeout=30)
        respuesta.raise_for_status()
        datos = respuesta.json()
        if not isinstance(datos, list):
            raise ValueError("La respuesta de la API no tiene el formato de lista esperado.")
        return datos
