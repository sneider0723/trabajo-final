# Guion breve para la sustentación

## Objetivo
Desarrollar una aplicación web que consulte datos abiertos del sector educativo colombiano, almacene registros en SQL Server y permita visualizarlos y filtrarlos desde el navegador.

## Dataset
Se seleccionó el conjunto MEN_ESTABLECIMIENTOS_EDUCATIVOS_PREESCOLAR_BÁSICA_Y_MEDIA, publicado por el Ministerio de Educación Nacional en datos.gov.co. El recurso es `cfw5-qzt5` y entrega datos en JSON.

## Demostración
1. Mostrar el endpoint de la API y un ejemplo de respuesta JSON.
2. Mostrar `api/api_client.py`, que realiza la petición HTTP.
3. Mostrar en SSMS la base `DatosAbiertosDB` y la tabla `Establecimientos`.
4. Ejecutar la aplicación Flask y pulsar el botón de sincronización.
5. Mostrar los registros guardados y probar el filtro.
6. Pulsar de nuevo sincronizar y explicar la prevención de duplicados.

## Explicación MVC
- Modelo: acceso a SQL Server y operaciones de persistencia/consulta.
- Vista: interfaz HTML/CSS que presenta la información.
- Controlador: rutas Flask que reciben solicitudes y coordinan el modelo y el servicio API.
- Servicio API: componente separado para comunicarse con datos.gov.co.

## Reparto oral
- **Sneider Castro** explica el conjunto de datos, API REST, endpoint y JSON.
- **Valery Arrieta Hoyos** explica la base de datos, tabla, pyodbc y prevención de duplicados.
- **Owen de la Hoz** explica Flask, rutas, MVC e interfaz web.
- Los tres deben poder explicar el flujo completo.

## Conclusión
El proyecto integra una fuente pública de datos con Python y SQL Server y presenta los resultados mediante una aplicación web sencilla. Se cumple el alcance de consulta, almacenamiento, búsqueda y resumen básico sin desarrollar CRUD completo.
