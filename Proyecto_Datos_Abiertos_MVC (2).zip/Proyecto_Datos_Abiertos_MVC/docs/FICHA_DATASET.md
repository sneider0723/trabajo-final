# Ficha del conjunto de datos

| Elemento | Descripción |
|---|---|
| Nombre | MEN_ESTABLECIMIENTOS_EDUCATIVOS_PREESCOLAR_BÁSICA_Y_MEDIA |
| Tema | Educación |
| Entidad | Ministerio de Educación Nacional |
| Portal | datos.gov.co |
| Identificador | cfw5-qzt5 |
| Endpoint JSON | https://www.datos.gov.co/resource/cfw5-qzt5.json?$limit=100 |
| Propósito | Información de establecimientos educativos de preescolar, básica y media |
| Cobertura | Nacional |
| Campos usados | a_o, departamento, municipio, codigo_dane, nombre_establecimiento, sector, caracter, calendario |

**Nota:** la ficha pública consultada describe 24 columnas y aproximadamente 606 mil filas. El proyecto limita cada consulta a 100 registros. Antes de la entrega, el equipo debe abrir la ficha y validar que el recurso y los campos continúan disponibles.
