IF DB_ID('DatosAbiertosDB') IS NULL
    CREATE DATABASE DatosAbiertosDB;
GO

USE DatosAbiertosDB;
GO

IF OBJECT_ID('dbo.Establecimientos', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Establecimientos (
        id INT IDENTITY(1,1) PRIMARY KEY,
        id_api NVARCHAR(120) NOT NULL UNIQUE,
        codigo_dane NVARCHAR(50) NOT NULL,
        anio NVARCHAR(10) NULL,
        departamento NVARCHAR(150) NULL,
        municipio NVARCHAR(150) NULL,
        nombre_establecimiento NVARCHAR(250) NULL,
        sector NVARCHAR(100) NULL,
        caracter NVARCHAR(150) NULL,
        calendario NVARCHAR(50) NULL,
        json_original NVARCHAR(MAX) NULL,
        fecha_captura DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    );
END;
GO

-- Consultas de comprobación
SELECT COUNT(*) AS total_registros FROM dbo.Establecimientos;
SELECT TOP 20 * FROM dbo.Establecimientos ORDER BY id DESC;
